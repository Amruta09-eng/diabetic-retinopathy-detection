import { Github } from "lucide-react";

export function Footer() {
  return (
    <footer className="w-full border-t bg-white py-8 mt-auto">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-center md:text-left">
            <p className="text-sm text-muted-foreground">
              Manipal University Jaipur
            </p>
            <p className="text-sm text-muted-foreground">
              Department of Computer Science & Engineering
            </p>
            <p className="text-sm text-muted-foreground">© 2026</p>
          </div>
          <a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
          >
            <Github className="size-5" />
            <span>View on GitHub</span>
          </a>
        </div>
      </div>
    </footer>
  );
}
