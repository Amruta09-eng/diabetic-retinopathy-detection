import { Outlet, Link, useLocation, useNavigate } from "react-router";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback } from "./ui/avatar";
import {
  LayoutDashboard,
  Activity,
  Calendar,
  FileText,
  FolderLock,
  User,
  LogOut,
  Eye,
  Menu,
  X,
} from "lucide-react";
import { Footer } from "./Footer";
import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";

const menuItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/dashboard" },
  { icon: Activity, label: "Start Screening", path: "/screening" },
  { icon: Calendar, label: "Book Doctor", path: "/doctor-booking" },
  { icon: FileText, label: "My Reports", path: "/reports" },
  { icon: FolderLock, label: "Medical Vault", path: "/medical-vault" },
  { icon: User, label: "Profile", path: "/profile" },
];

export function DashboardLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => {
    navigate("/");
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Mobile Header */}
      <header className="lg:hidden bg-white border-b px-4 py-3 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <Eye className="size-6 text-primary" />
          <span className="font-semibold">RetinaGuard AI</span>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setSidebarOpen(!sidebarOpen)}
        >
          {sidebarOpen ? <X className="size-6" /> : <Menu className="size-6" />}
        </Button>
      </header>

      <div className="flex flex-1">
        {/* Sidebar */}
        <AnimatePresence>
          {(sidebarOpen || window.innerWidth >= 1024) && (
            <motion.aside
              initial={{ x: -300 }}
              animate={{ x: 0 }}
              exit={{ x: -300 }}
              transition={{ type: "spring", damping: 25 }}
              className="fixed lg:sticky top-0 left-0 h-screen w-64 bg-white border-r flex flex-col z-40 lg:z-auto"
            >
              {/* Logo */}
              <div className="p-6 border-b hidden lg:block">
                <Link to="/" className="flex items-center gap-2">
                  <Eye className="size-8 text-primary" />
                  <div>
                    <div className="font-semibold text-foreground">
                      RetinaGuard AI
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Patient Portal
                    </div>
                  </div>
                </Link>
              </div>

              {/* User Info */}
              <div className="p-6 border-b">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      JD
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">John Doe</div>
                    <div className="text-sm text-muted-foreground truncate">
                      john.doe@example.com
                    </div>
                  </div>
                </div>
              </div>

              {/* Navigation */}
              <nav className="flex-1 p-4 overflow-y-auto">
                <div className="space-y-1">
                  {menuItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = location.pathname === item.path;
                    return (
                      <Link key={item.path} to={item.path}>
                        <Button
                          variant={isActive ? "default" : "ghost"}
                          className="w-full justify-start"
                          onClick={() => setSidebarOpen(false)}
                        >
                          <Icon className="mr-3 size-5" />
                          {item.label}
                        </Button>
                      </Link>
                    );
                  })}
                </div>
              </nav>

              {/* Logout */}
              <div className="p-4 border-t">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10"
                  onClick={handleLogout}
                >
                  <LogOut className="mr-3 size-5" />
                  Logout
                </Button>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* Overlay for mobile */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-30 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-w-0">
          <main className="flex-1 p-4 md:p-8">
            <Outlet />
          </main>
          <Footer />
        </div>
      </div>
    </div>
  );
}
