import { Link } from "react-router";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import {
  Activity,
  Calendar,
  FileText,
  ArrowRight,
  Clock,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import { motion } from "motion/react";

export function PatientDashboard() {
  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Welcome Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-semibold mb-2">Welcome back, John!</h1>
        <p className="text-muted-foreground">
          Here's an overview of your health dashboard
        </p>
      </motion.div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="grid md:grid-cols-3 gap-6"
      >
        <QuickActionCard
          icon={<Activity className="size-6 text-primary" />}
          title="Start Screening"
          description="Run AI retinal analysis"
          link="/screening"
          variant="primary"
        />
        <QuickActionCard
          icon={<Calendar className="size-6 text-primary" />}
          title="Book Appointment"
          description="Schedule with a doctor"
          link="/doctor-booking"
        />
        <QuickActionCard
          icon={<FileText className="size-6 text-primary" />}
          title="View Reports"
          description="Access medical records"
          link="/reports"
        />
      </motion.div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Upcoming Appointments */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Appointments</CardTitle>
              <CardDescription>Your scheduled consultations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <AppointmentItem
                doctorName="Dr. Sarah Williams"
                specialty="Ophthalmologist"
                date="Feb 18, 2026"
                time="10:30 AM"
                status="confirmed"
              />
              <AppointmentItem
                doctorName="Dr. Michael Chen"
                specialty="Retinal Specialist"
                date="Feb 22, 2026"
                time="2:00 PM"
                status="pending"
              />
              <Link to="/doctor-booking">
                <Button variant="outline" className="w-full mt-4">
                  Book New Appointment
                  <ArrowRight className="ml-2 size-4" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </motion.div>

        {/* Recent Screening */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Recent Screening Results</CardTitle>
              <CardDescription>Latest AI analysis</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <ScreeningResultItem
                date="Feb 10, 2026"
                result="No DR Detected"
                confidence={94}
                status="success"
              />
              <ScreeningResultItem
                date="Jan 15, 2026"
                result="Mild DR Detected"
                confidence={87}
                status="warning"
              />
              <Link to="/screening">
                <Button className="w-full mt-4">
                  <Activity className="mr-2 size-4" />
                  Start New Screening
                </Button>
              </Link>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Health Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <Card>
          <CardHeader>
            <CardTitle>Health Summary</CardTitle>
            <CardDescription>Your medical information at a glance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-6">
              <SummaryItem label="Total Screenings" value="8" />
              <SummaryItem label="Appointments" value="12" />
              <SummaryItem label="Documents" value="24" />
              <SummaryItem label="Last Visit" value="10 days ago" />
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}

function QuickActionCard({
  icon,
  title,
  description,
  link,
  variant = "default",
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  link: string;
  variant?: "default" | "primary";
}) {
  return (
    <Link to={link}>
      <Card
        className={`hover:shadow-lg transition-all cursor-pointer ${
          variant === "primary" ? "border-primary bg-primary/5" : ""
        }`}
      >
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div
              className={`p-3 rounded-lg ${
                variant === "primary" ? "bg-primary/10" : "bg-muted"
              }`}
            >
              {icon}
            </div>
            <div className="flex-1">
              <h3 className="font-semibold mb-1">{title}</h3>
              <p className="text-sm text-muted-foreground">{description}</p>
            </div>
            <ArrowRight className="size-5 text-muted-foreground" />
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

function AppointmentItem({
  doctorName,
  specialty,
  date,
  time,
  status,
}: {
  doctorName: string;
  specialty: string;
  date: string;
  time: string;
  status: "confirmed" | "pending";
}) {
  return (
    <div className="flex items-start gap-3 p-4 bg-muted/30 rounded-lg">
      <Calendar className="size-5 text-primary mt-0.5" />
      <div className="flex-1">
        <div className="font-medium">{doctorName}</div>
        <div className="text-sm text-muted-foreground">{specialty}</div>
        <div className="flex items-center gap-2 mt-2 text-sm">
          <Clock className="size-3.5" />
          <span>
            {date} at {time}
          </span>
        </div>
      </div>
      <Badge variant={status === "confirmed" ? "default" : "secondary"}>
        {status}
      </Badge>
    </div>
  );
}

function ScreeningResultItem({
  date,
  result,
  confidence,
  status,
}: {
  date: string;
  result: string;
  confidence: number;
  status: "success" | "warning";
}) {
  return (
    <div className="flex items-start gap-3 p-4 bg-muted/30 rounded-lg">
      {status === "success" ? (
        <CheckCircle2 className="size-5 text-[#198754] mt-0.5" />
      ) : (
        <AlertCircle className="size-5 text-yellow-600 mt-0.5" />
      )}
      <div className="flex-1">
        <div className="font-medium">{result}</div>
        <div className="text-sm text-muted-foreground">{date}</div>
        <div className="mt-2">
          <div className="flex items-center justify-between text-sm mb-1">
            <span>Confidence</span>
            <span className="font-medium">{confidence}%</span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div
              className={`h-2 rounded-full ${
                status === "success" ? "bg-[#198754]" : "bg-yellow-600"
              }`}
              style={{ width: `${confidence}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function SummaryItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="text-center">
      <div className="text-3xl font-semibold text-primary mb-1">{value}</div>
      <div className="text-sm text-muted-foreground">{label}</div>
    </div>
  );
}
