import { Button } from "../components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import {
  FileText,
  Download,
  Eye,
  Calendar,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import { motion } from "motion/react";

const reports = [
  {
    id: 1,
    title: "AI Retinal Screening Report",
    date: "Feb 10, 2026",
    result: "No DR Detected",
    confidence: 94,
    status: "success",
  },
  {
    id: 2,
    title: "AI Retinal Screening Report",
    date: "Jan 15, 2026",
    result: "Mild DR Detected",
    confidence: 87,
    status: "warning",
  },
  {
    id: 3,
    title: "Comprehensive Eye Examination",
    date: "Dec 20, 2025",
    result: "Normal",
    confidence: 100,
    status: "success",
  },
  {
    id: 4,
    title: "AI Retinal Screening Report",
    date: "Nov 10, 2025",
    result: "No DR Detected",
    confidence: 92,
    status: "success",
  },
];

export function ReportsPage() {
  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-semibold mb-2">My Reports</h1>
        <p className="text-muted-foreground">
          View and download your screening history
        </p>
      </motion.div>

      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Card>
            <CardContent className="p-6">
              <div className="text-center">
                <div className="text-3xl font-semibold text-primary mb-1">
                  {reports.length}
                </div>
                <div className="text-sm text-muted-foreground">Total Reports</div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.15 }}
        >
          <Card>
            <CardContent className="p-6">
              <div className="text-center">
                <div className="text-3xl font-semibold text-[#198754] mb-1">
                  {reports.filter((r) => r.status === "success").length}
                </div>
                <div className="text-sm text-muted-foreground">Clear Results</div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card>
            <CardContent className="p-6">
              <div className="text-center">
                <div className="text-3xl font-semibold text-yellow-600 mb-1">
                  {reports.filter((r) => r.status === "warning").length}
                </div>
                <div className="text-sm text-muted-foreground">Needs Attention</div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.25 }}
        >
          <Card>
            <CardContent className="p-6">
              <div className="text-center">
                <div className="text-3xl font-semibold text-primary mb-1">
                  93%
                </div>
                <div className="text-sm text-muted-foreground">Avg. Confidence</div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Reports List */}
      <div className="space-y-4">
        {reports.map((report, index) => (
          <motion.div
            key={report.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
          >
            <Card className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
                  <div
                    className={`p-3 rounded-lg flex-shrink-0 ${
                      report.status === "success"
                        ? "bg-[#198754]/10"
                        : "bg-yellow-600/10"
                    }`}
                  >
                    <FileText
                      className={`size-6 ${
                        report.status === "success"
                          ? "text-[#198754]"
                          : "text-yellow-600"
                      }`}
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-2">
                      <h3 className="text-lg font-semibold">{report.title}</h3>
                      {report.status === "success" ? (
                        <CheckCircle2 className="size-5 text-[#198754]" />
                      ) : (
                        <AlertCircle className="size-5 text-yellow-600" />
                      )}
                    </div>
                    <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="size-3.5" />
                        <span>{report.date}</span>
                      </div>
                      <Badge
                        variant={
                          report.status === "success" ? "default" : "secondary"
                        }
                        className={
                          report.status === "success"
                            ? "bg-[#198754] hover:bg-[#198754]"
                            : "bg-yellow-600 hover:bg-yellow-600 text-white"
                        }
                      >
                        {report.result}
                      </Badge>
                      <span>Confidence: {report.confidence}%</span>
                    </div>
                  </div>
                  <div className="flex gap-2 flex-shrink-0">
                    <Button variant="outline" size="sm">
                      <Eye className="mr-2 size-4" />
                      View
                    </Button>
                    <Button variant="outline" size="sm">
                      <Download className="mr-2 size-4" />
                      Download
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
