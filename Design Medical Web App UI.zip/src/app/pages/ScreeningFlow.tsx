import { useState } from "react";
import { useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Checkbox } from "../components/ui/checkbox";
import { Progress } from "../components/ui/progress";
import {
  Upload,
  Camera,
  X,
  ArrowRight,
  ArrowLeft,
  Loader2,
} from "lucide-react";
import { motion } from "motion/react";

export function ScreeningFlow() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Step 1 - Patient Details
  const [patientDetails, setPatientDetails] = useState({
    name: "",
    age: "",
    diabetesDuration: "",
    symptoms: {
      blurredVision: false,
      floaters: false,
      darkSpots: false,
      colorVision: false,
      nightVision: false,
    },
  });

  // Step 2 - Image Upload
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRunScreening = () => {
    setIsProcessing(true);
    setStep(3);
    // Simulate processing
    setTimeout(() => {
      navigate("/screening/result");
    }, 3000);
  };

  const progress = (step / 3) * 100;

  return (
    <div className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-8">
          <h1 className="text-3xl font-semibold mb-2">AI Retinal Screening</h1>
          <p className="text-muted-foreground">
            Complete the following steps to analyze your retinal images
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between mb-2">
            <span className="text-sm font-medium">
              Step {step} of 3
            </span>
            <span className="text-sm text-muted-foreground">
              {step === 1 && "Patient Details"}
              {step === 2 && "Image Upload"}
              {step === 3 && "Processing"}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Step 1: Patient Details */}
        {step === 1 && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Patient Details</CardTitle>
                <CardDescription>
                  Provide your information for accurate screening
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      placeholder="Enter your name"
                      value={patientDetails.name}
                      onChange={(e) =>
                        setPatientDetails({
                          ...patientDetails,
                          name: e.target.value,
                        })
                      }
                      className="bg-input-background"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="age">Age</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="Enter your age"
                      value={patientDetails.age}
                      onChange={(e) =>
                        setPatientDetails({
                          ...patientDetails,
                          age: e.target.value,
                        })
                      }
                      className="bg-input-background"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="duration">Diabetes Duration (years)</Label>
                  <Input
                    id="duration"
                    type="number"
                    placeholder="How long have you had diabetes?"
                    value={patientDetails.diabetesDuration}
                    onChange={(e) =>
                      setPatientDetails({
                        ...patientDetails,
                        diabetesDuration: e.target.value,
                      })
                    }
                    className="bg-input-background"
                  />
                </div>

                <div className="space-y-3">
                  <Label>Symptoms (Select all that apply)</Label>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="blurred"
                        checked={patientDetails.symptoms.blurredVision}
                        onCheckedChange={(checked) =>
                          setPatientDetails({
                            ...patientDetails,
                            symptoms: {
                              ...patientDetails.symptoms,
                              blurredVision: checked as boolean,
                            },
                          })
                        }
                      />
                      <label htmlFor="blurred" className="text-sm cursor-pointer">
                        Blurred vision
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="floaters"
                        checked={patientDetails.symptoms.floaters}
                        onCheckedChange={(checked) =>
                          setPatientDetails({
                            ...patientDetails,
                            symptoms: {
                              ...patientDetails.symptoms,
                              floaters: checked as boolean,
                            },
                          })
                        }
                      />
                      <label htmlFor="floaters" className="text-sm cursor-pointer">
                        Floaters or spots
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="dark"
                        checked={patientDetails.symptoms.darkSpots}
                        onCheckedChange={(checked) =>
                          setPatientDetails({
                            ...patientDetails,
                            symptoms: {
                              ...patientDetails.symptoms,
                              darkSpots: checked as boolean,
                            },
                          })
                        }
                      />
                      <label htmlFor="dark" className="text-sm cursor-pointer">
                        Dark or empty areas in vision
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="color"
                        checked={patientDetails.symptoms.colorVision}
                        onCheckedChange={(checked) =>
                          setPatientDetails({
                            ...patientDetails,
                            symptoms: {
                              ...patientDetails.symptoms,
                              colorVision: checked as boolean,
                            },
                          })
                        }
                      />
                      <label htmlFor="color" className="text-sm cursor-pointer">
                        Difficulty seeing colors
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="night"
                        checked={patientDetails.symptoms.nightVision}
                        onCheckedChange={(checked) =>
                          setPatientDetails({
                            ...patientDetails,
                            symptoms: {
                              ...patientDetails.symptoms,
                              nightVision: checked as boolean,
                            },
                          })
                        }
                      />
                      <label htmlFor="night" className="text-sm cursor-pointer">
                        Poor night vision
                      </label>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button
                    variant="outline"
                    onClick={() => navigate("/dashboard")}
                  >
                    Cancel
                  </Button>
                  <Button onClick={() => setStep(2)}>
                    Continue
                    <ArrowRight className="ml-2 size-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Step 2: Image Upload */}
        {step === 2 && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Upload Retinal Image</CardTitle>
                <CardDescription>
                  Upload a clear fundus photograph of your retina
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {!uploadedImage ? (
                  <div className="border-2 border-dashed rounded-lg p-12 text-center hover:border-primary transition-colors cursor-pointer">
                    <input
                      type="file"
                      id="file-upload"
                      className="hidden"
                      accept="image/*"
                      onChange={handleFileUpload}
                    />
                    <label htmlFor="file-upload" className="cursor-pointer">
                      <Upload className="size-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-lg font-medium mb-2">
                        Drag and drop your image here
                      </p>
                      <p className="text-sm text-muted-foreground mb-4">
                        or click to browse files
                      </p>
                      <Button type="button" variant="outline">
                        <Upload className="mr-2 size-4" />
                        Choose File
                      </Button>
                    </label>
                  </div>
                ) : (
                  <div className="relative">
                    <img
                      src={uploadedImage}
                      alt="Uploaded retinal scan"
                      className="w-full rounded-lg border"
                    />
                    <Button
                      variant="destructive"
                      size="sm"
                      className="absolute top-2 right-2"
                      onClick={() => setUploadedImage(null)}
                    >
                      <X className="size-4 mr-1" />
                      Remove
                    </Button>
                  </div>
                )}

                <div className="flex gap-3">
                  <Button variant="outline" className="flex-1">
                    <Camera className="mr-2 size-4" />
                    Use Camera
                  </Button>
                  <label htmlFor="file-upload" className="flex-1">
                    <Button variant="outline" className="w-full" type="button">
                      <Upload className="mr-2 size-4" />
                      Upload File
                    </Button>
                  </label>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="text-sm text-blue-900">
                    <strong>Tips for best results:</strong>
                  </p>
                  <ul className="text-sm text-blue-800 mt-2 space-y-1 list-disc list-inside">
                    <li>Use a high-quality fundus camera image</li>
                    <li>Ensure the image is well-lit and in focus</li>
                    <li>Center the optic disc and macula</li>
                    <li>Avoid blurry or dark images</li>
                  </ul>
                </div>

                <div className="flex justify-between gap-3 pt-4">
                  <Button variant="outline" onClick={() => setStep(1)}>
                    <ArrowLeft className="mr-2 size-4" />
                    Back
                  </Button>
                  <Button
                    onClick={handleRunScreening}
                    disabled={!uploadedImage}
                  >
                    Run Screening
                    <ArrowRight className="ml-2 size-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Step 3: Processing */}
        {step === 3 && isProcessing && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <Card>
              <CardContent className="p-12">
                <div className="text-center space-y-6">
                  <div className="inline-flex items-center justify-center w-20 h-20 bg-primary/10 rounded-full mb-4">
                    <Loader2 className="size-10 text-primary animate-spin" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-semibold mb-2">
                      Analyzing Retinal Image...
                    </h3>
                    <p className="text-muted-foreground">
                      Our AI is processing your scan. This may take a few moments.
                    </p>
                  </div>
                  <div className="max-w-md mx-auto">
                    <Progress value={66} className="h-2" />
                    <p className="text-sm text-muted-foreground mt-2">
                      Processing image features and detecting abnormalities
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}
