import { Link } from "react-router";
import { Button } from "../components/ui/button";
import { Footer } from "../components/Footer";
import { Eye, Stethoscope, Shield, Activity } from "lucide-react";
import { motion } from "motion/react";

export function LandingPage() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-background via-blue-50/30 to-background">
      {/* Header */}
      <header className="w-full py-6 px-4 bg-white/80 backdrop-blur-sm border-b sticky top-0 z-50">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Eye className="size-8 text-primary" />
            <span className="text-xl font-semibold text-foreground">
              RetinaGuard AI
            </span>
          </div>
          <div className="flex gap-3">
            <Link to="/login">
              <Button variant="outline">Login</Button>
            </Link>
            <Link to="/signup">
              <Button>Get Started</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col">
        <section className="container mx-auto px-4 py-16 md:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-4xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full mb-6">
              <Shield className="size-4" />
              <span className="text-sm">Medical-Grade AI Technology</span>
            </div>

            <h1 className="text-4xl md:text-6xl font-semibold text-foreground mb-6 leading-tight">
              Early Detection of
              <br />
              <span className="text-primary">Diabetic Retinopathy</span>
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
              AI-powered retinal screening platform for early detection and
              prevention. Get instant analysis and connect with specialist
              doctors.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/dashboard">
                <Button size="lg" className="w-full sm:w-auto px-8">
                  <Activity className="mr-2 size-5" />
                  Start Screening
                </Button>
              </Link>
              <Link to="/login">
                <Button size="lg" variant="outline" className="w-full sm:w-auto px-8">
                  Login to Account
                </Button>
              </Link>
              <Link to="/doctor-booking">
                <Button size="lg" variant="outline" className="w-full sm:w-auto px-8">
                  <Stethoscope className="mr-2 size-5" />
                  Book Doctor
                </Button>
              </Link>
            </div>
          </motion.div>

          {/* Feature Cards */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="grid md:grid-cols-3 gap-6 mt-20"
          >
            <FeatureCard
              icon={<Eye className="size-8 text-primary" />}
              title="AI Retinal Screening"
              description="Advanced AI algorithms analyze retinal images for early signs of diabetic retinopathy."
            />
            <FeatureCard
              icon={<Stethoscope className="size-8 text-primary" />}
              title="Expert Doctors"
              description="Connect with qualified ophthalmologists and schedule appointments instantly."
            />
            <FeatureCard
              icon={<Shield className="size-8 text-primary" />}
              title="Secure Medical Vault"
              description="Store and manage all your medical documents and reports securely in one place."
            />
          </motion.div>
        </section>

        {/* Stats Section */}
        <section className="bg-white py-16">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-4 gap-8 text-center">
              <StatCard number="95%" label="Accuracy Rate" />
              <StatCard number="10K+" label="Screenings Done" />
              <StatCard number="500+" label="Doctors" />
              <StatCard number="24/7" label="Support" />
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="bg-white rounded-xl p-8 shadow-sm border hover:shadow-md transition-shadow">
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>
  );
}

function StatCard({ number, label }: { number: string; label: string }) {
  return (
    <div>
      <div className="text-4xl font-semibold text-primary mb-2">{number}</div>
      <div className="text-muted-foreground">{label}</div>
    </div>
  );
}
