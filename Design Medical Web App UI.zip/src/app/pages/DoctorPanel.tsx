import { useState } from "react";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Textarea } from "../components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import {
  Calendar,
  FileText,
  User,
  Clock,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import { motion } from "motion/react";

const appointments = [
  {
    id: 1,
    patientName: "John Doe",
    age: 45,
    time: "10:30 AM",
    date: "Feb 14, 2026",
    status: "scheduled",
    type: "Follow-up",
  },
  {
    id: 2,
    patientName: "Jane Smith",
    age: 52,
    time: "11:00 AM",
    date: "Feb 14, 2026",
    status: "scheduled",
    type: "Screening Review",
  },
  {
    id: 3,
    patientName: "Robert Johnson",
    age: 38,
    time: "02:00 PM",
    date: "Feb 14, 2026",
    status: "completed",
    type: "Consultation",
  },
];

const patientReports = [
  {
    id: 1,
    patientName: "John Doe",
    date: "Feb 10, 2026",
    result: "No DR Detected",
    confidence: 94,
    status: "success",
  },
  {
    id: 2,
    patientName: "Jane Smith",
    date: "Feb 8, 2026",
    result: "Mild DR Detected",
    confidence: 87,
    status: "warning",
  },
];

export function DoctorPanel() {
  const [selectedPatient, setSelectedPatient] = useState<string | null>(null);
  const [notes, setNotes] = useState("");

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-semibold mb-2">Doctor Panel</h1>
        <p className="text-muted-foreground">
          Manage appointments and review patient reports
        </p>
      </motion.div>

      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Today's Appointments</p>
                  <p className="text-3xl font-semibold text-primary">
                    {appointments.filter((a) => a.status === "scheduled").length}
                  </p>
                </div>
                <Calendar className="size-8 text-primary opacity-50" />
              </div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.15 }}
        >
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Completed</p>
                  <p className="text-3xl font-semibold text-[#198754]">
                    {appointments.filter((a) => a.status === "completed").length}
                  </p>
                </div>
                <CheckCircle2 className="size-8 text-[#198754] opacity-50" />
              </div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Pending Reports</p>
                  <p className="text-3xl font-semibold text-yellow-600">
                    {patientReports.filter((r) => r.status === "warning").length}
                  </p>
                </div>
                <FileText className="size-8 text-yellow-600 opacity-50" />
              </div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.25 }}
        >
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Patients</p>
                  <p className="text-3xl font-semibold text-primary">156</p>
                </div>
                <User className="size-8 text-primary opacity-50" />
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <Tabs defaultValue="appointments">
        <TabsList className="grid w-full grid-cols-2 max-w-md">
          <TabsTrigger value="appointments">Appointments</TabsTrigger>
          <TabsTrigger value="reports">Patient Reports</TabsTrigger>
        </TabsList>

        {/* Appointments Tab */}
        <TabsContent value="appointments" className="mt-6 space-y-4">
          {appointments.map((appointment, index) => (
            <motion.div
              key={appointment.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
            >
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold">
                          {appointment.patientName}
                        </h3>
                        <Badge
                          variant={
                            appointment.status === "completed"
                              ? "default"
                              : "secondary"
                          }
                          className={
                            appointment.status === "completed"
                              ? "bg-[#198754] hover:bg-[#198754]"
                              : ""
                          }
                        >
                          {appointment.status}
                        </Badge>
                      </div>
                      <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <User className="size-3.5" />
                          <span>Age: {appointment.age}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="size-3.5" />
                          <span>{appointment.time}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="size-3.5" />
                          <span>{appointment.date}</span>
                        </div>
                        <Badge variant="outline">{appointment.type}</Badge>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        onClick={() => setSelectedPatient(appointment.patientName)}
                      >
                        View Details
                      </Button>
                      {appointment.status === "scheduled" && (
                        <Button>Mark Complete</Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </TabsContent>

        {/* Patient Reports Tab */}
        <TabsContent value="reports" className="mt-6 space-y-4">
          {patientReports.map((report, index) => (
            <motion.div
              key={report.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
            >
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
                    <div
                      className={`p-3 rounded-lg flex-shrink-0 ${
                        report.status === "success"
                          ? "bg-[#198754]/10"
                          : "bg-yellow-600/10"
                      }`}
                    >
                      {report.status === "success" ? (
                        <CheckCircle2 className="size-6 text-[#198754]" />
                      ) : (
                        <AlertCircle className="size-6 text-yellow-600" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold mb-2">
                        {report.patientName}
                      </h3>
                      <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                        <span>{report.date}</span>
                        <Badge
                          variant={
                            report.status === "success" ? "default" : "secondary"
                          }
                          className={
                            report.status === "success"
                              ? "bg-[#198754] hover:bg-[#198754]"
                              : "bg-yellow-600 hover:bg-yellow-600 text-white"
                          }
                        >
                          {report.result}
                        </Badge>
                        <span>Confidence: {report.confidence}%</span>
                      </div>
                    </div>
                    <Button variant="outline">Review Report</Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </TabsContent>
      </Tabs>

      {/* Add Notes Section */}
      <Card>
        <CardHeader>
          <CardTitle>Add Clinical Notes</CardTitle>
          <CardDescription>
            Document observations and recommendations
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Enter clinical notes, observations, or treatment recommendations..."
            className="min-h-32 bg-input-background"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
          <div className="flex justify-end gap-3">
            <Button variant="outline">Cancel</Button>
            <Button>Save Notes</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
