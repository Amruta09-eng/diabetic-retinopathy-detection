import { Link } from "react-router";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import {
  CheckCircle2,
  AlertCircle,
  Download,
  Calendar,
  FolderLock,
  Activity,
  AlertTriangle,
} from "lucide-react";
import { motion } from "motion/react";

export function ResultScreen() {
  // Mock result - can be 'success' or 'warning'
  const result = {
    status: "success", // or "warning"
    diagnosis: "No DR Detected",
    confidence: 94,
    date: "February 14, 2026",
    time: "10:45 AM",
  };

  const isSuccess = result.status === "success";

  return (
    <div className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-8"
      >
        {/* Result Card */}
        <Card
          className={`border-2 ${
            isSuccess ? "border-[#198754]" : "border-yellow-600"
          }`}
        >
          <CardContent className="p-8">
            <div className="text-center space-y-6">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", duration: 0.6 }}
                className={`inline-flex items-center justify-center w-24 h-24 rounded-full ${
                  isSuccess ? "bg-[#198754]/10" : "bg-yellow-600/10"
                } mb-4`}
              >
                {isSuccess ? (
                  <CheckCircle2 className="size-16 text-[#198754]" />
                ) : (
                  <AlertCircle className="size-16 text-yellow-600" />
                )}
              </motion.div>

              <div>
                <Badge
                  variant={isSuccess ? "default" : "secondary"}
                  className={`mb-4 ${
                    isSuccess
                      ? "bg-[#198754] hover:bg-[#198754]"
                      : "bg-yellow-600 hover:bg-yellow-600 text-white"
                  }`}
                >
                  Screening Complete
                </Badge>
                <h1 className="text-4xl font-semibold mb-2">
                  {result.diagnosis}
                </h1>
                <p className="text-muted-foreground">
                  Analysis completed on {result.date} at {result.time}
                </p>
              </div>

              <div className="max-w-md mx-auto">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Confidence Level</span>
                  <span className="text-2xl font-semibold text-primary">
                    {result.confidence}%
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-3">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${result.confidence}%` }}
                    transition={{ duration: 1, delay: 0.3 }}
                    className={`h-3 rounded-full ${
                      isSuccess ? "bg-[#198754]" : "bg-yellow-600"
                    }`}
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="grid md:grid-cols-4 gap-4">
          <Button className="w-full" size="lg">
            <Download className="mr-2 size-4" />
            Download Report
          </Button>
          <Link to="/doctor-booking" className="w-full">
            <Button variant="outline" className="w-full" size="lg">
              <Calendar className="mr-2 size-4" />
              Book Doctor
            </Button>
          </Link>
          <Link to="/medical-vault" className="w-full">
            <Button variant="outline" className="w-full" size="lg">
              <FolderLock className="mr-2 size-4" />
              Save to Vault
            </Button>
          </Link>
          <Link to="/screening" className="w-full">
            <Button variant="outline" className="w-full" size="lg">
              <Activity className="mr-2 size-4" />
              New Screening
            </Button>
          </Link>
        </div>

        {/* Detailed Analysis */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Analysis Details</CardTitle>
              <CardDescription>AI detection breakdown</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <AnalysisItem
                label="Microaneurysms"
                value="Not Detected"
                status="success"
              />
              <AnalysisItem
                label="Hemorrhages"
                value="Not Detected"
                status="success"
              />
              <AnalysisItem
                label="Hard Exudates"
                value="Not Detected"
                status="success"
              />
              <AnalysisItem
                label="Soft Exudates"
                value="Not Detected"
                status="success"
              />
              <AnalysisItem
                label="Neovascularization"
                value="Not Detected"
                status="success"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recommendations</CardTitle>
              <CardDescription>Next steps for your eye health</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <RecommendationItem text="Continue regular monitoring every 6 months" />
              <RecommendationItem text="Maintain blood sugar control" />
              <RecommendationItem text="Schedule annual comprehensive eye exam" />
              <RecommendationItem text="Report any vision changes immediately" />
            </CardContent>
          </Card>
        </div>

        {/* Disclaimer */}
        <Card className="bg-amber-50 border-amber-200">
          <CardContent className="p-6">
            <div className="flex gap-4">
              <AlertTriangle className="size-6 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-amber-900 mb-2">
                  Important Medical Disclaimer
                </h4>
                <p className="text-sm text-amber-800">
                  This AI screening is a supportive tool and not a substitute
                  for professional medical diagnosis. Always consult with a
                  qualified ophthalmologist or healthcare provider for
                  definitive diagnosis and treatment. If you experience any
                  vision changes or symptoms, seek immediate medical attention.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Image Preview */}
        <Card>
          <CardHeader>
            <CardTitle>Analyzed Image</CardTitle>
            <CardDescription>Your retinal scan with annotations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-muted rounded-lg aspect-video flex items-center justify-center">
              <p className="text-muted-foreground">Retinal image preview</p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}

function AnalysisItem({
  label,
  value,
  status,
}: {
  label: string;
  value: string;
  status: "success" | "warning";
}) {
  return (
    <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
      <span className="font-medium">{label}</span>
      <div className="flex items-center gap-2">
        <span
          className={`text-sm ${
            status === "success" ? "text-[#198754]" : "text-yellow-600"
          }`}
        >
          {value}
        </span>
        {status === "success" ? (
          <CheckCircle2 className="size-4 text-[#198754]" />
        ) : (
          <AlertCircle className="size-4 text-yellow-600" />
        )}
      </div>
    </div>
  );
}

function RecommendationItem({ text }: { text: string }) {
  return (
    <div className="flex items-start gap-2">
      <div className="size-2 rounded-full bg-primary mt-2 flex-shrink-0" />
      <p className="text-sm">{text}</p>
    </div>
  );
}
