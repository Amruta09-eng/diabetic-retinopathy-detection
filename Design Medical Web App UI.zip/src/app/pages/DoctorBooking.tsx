import { useState } from "react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Avatar, AvatarFallback } from "../components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "../components/ui/dialog";
import { Calendar } from "../components/ui/calendar";
import {
  Search,
  Star,
  MapPin,
  Calendar as CalendarIcon,
  Clock,
  CheckCircle2,
} from "lucide-react";
import { motion } from "motion/react";

const doctors = [
  {
    id: 1,
    name: "Dr. Sarah Williams",
    specialty: "Ophthalmologist",
    experience: 15,
    rating: 4.9,
    reviews: 248,
    location: "Jaipur Eye Hospital",
    availability: "Available Today",
    initials: "SW",
  },
  {
    id: 2,
    name: "Dr. Michael Chen",
    specialty: "Retinal Specialist",
    experience: 12,
    rating: 4.8,
    reviews: 192,
    location: "Vision Care Center",
    availability: "Next Available: Tomorrow",
    initials: "MC",
  },
  {
    id: 3,
    name: "Dr. Priya Sharma",
    specialty: "Diabetic Eye Specialist",
    experience: 18,
    rating: 5.0,
    reviews: 312,
    location: "Manipal Hospital Jaipur",
    availability: "Available Today",
    initials: "PS",
  },
  {
    id: 4,
    name: "Dr. James Rodriguez",
    specialty: "Ophthalmologist",
    experience: 10,
    rating: 4.7,
    reviews: 156,
    location: "Eye Care Clinic",
    availability: "Next Available: Feb 16",
    initials: "JR",
  },
];

const timeSlots = [
  "09:00 AM",
  "10:00 AM",
  "11:00 AM",
  "02:00 PM",
  "03:00 PM",
  "04:00 PM",
];

export function DoctorBooking() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDoctor, setSelectedDoctor] = useState<typeof doctors[0] | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [selectedTime, setSelectedTime] = useState<string>("");
  const [showConfirmation, setShowConfirmation] = useState(false);

  const filteredDoctors = doctors.filter(
    (doctor) =>
      doctor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doctor.specialty.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleBookAppointment = () => {
    setShowConfirmation(true);
    setTimeout(() => {
      setShowConfirmation(false);
      setSelectedDoctor(null);
      setSelectedTime("");
    }, 3000);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-semibold mb-2">Book an Appointment</h1>
        <p className="text-muted-foreground">
          Schedule a consultation with our expert ophthalmologists
        </p>
      </motion.div>

      {/* Search */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-5 text-muted-foreground" />
          <Input
            placeholder="Search by doctor name or specialty..."
            className="pl-10 bg-white"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </motion.div>

      {/* Doctor Cards */}
      <div className="grid md:grid-cols-2 gap-6">
        {filteredDoctors.map((doctor, index) => (
          <motion.div
            key={doctor.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
          >
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex gap-4">
                  <Avatar className="size-16">
                    <AvatarFallback className="bg-primary text-primary-foreground text-lg">
                      {doctor.initials}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold mb-1">{doctor.name}</h3>
                    <p className="text-sm text-muted-foreground mb-2">
                      {doctor.specialty}
                    </p>
                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="secondary" className="text-xs">
                        {doctor.experience} years exp.
                      </Badge>
                      <div className="flex items-center gap-1 text-sm">
                        <Star className="size-3.5 fill-yellow-500 text-yellow-500" />
                        <span className="font-medium">{doctor.rating}</span>
                        <span className="text-muted-foreground">
                          ({doctor.reviews})
                        </span>
                      </div>
                    </div>
                    <div className="space-y-1 mb-4">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="size-3.5" />
                        <span>{doctor.location}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="size-3.5 text-[#198754]" />
                        <span className="text-[#198754] font-medium">
                          {doctor.availability}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        className="flex-1"
                        onClick={() => setSelectedDoctor(doctor)}
                      >
                        Book Appointment
                      </Button>
                      <Button variant="outline">View Profile</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Booking Dialog */}
      <Dialog
        open={!!selectedDoctor}
        onOpenChange={() => setSelectedDoctor(null)}
      >
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Book Appointment with {selectedDoctor?.name}</DialogTitle>
            <DialogDescription>
              Select your preferred date and time
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {/* Date Selection */}
            <div>
              <h4 className="font-medium mb-3">Select Date</h4>
              <div className="flex justify-center">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border"
                  disabled={(date) => date < new Date()}
                />
              </div>
            </div>

            {/* Time Selection */}
            <div>
              <h4 className="font-medium mb-3">Select Time</h4>
              <div className="grid grid-cols-3 gap-3">
                {timeSlots.map((time) => (
                  <Button
                    key={time}
                    variant={selectedTime === time ? "default" : "outline"}
                    className="w-full"
                    onClick={() => setSelectedTime(time)}
                  >
                    {time}
                  </Button>
                ))}
              </div>
            </div>

            {/* Appointment Summary */}
            {selectedDate && selectedTime && (
              <Card className="bg-muted/30">
                <CardContent className="p-4">
                  <h4 className="font-medium mb-3">Appointment Summary</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Doctor:</span>
                      <span className="font-medium">{selectedDoctor?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Date:</span>
                      <span className="font-medium">
                        {selectedDate.toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Time:</span>
                      <span className="font-medium">{selectedTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Location:</span>
                      <span className="font-medium">
                        {selectedDoctor?.location}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <Button
              className="w-full"
              size="lg"
              disabled={!selectedDate || !selectedTime}
              onClick={handleBookAppointment}
            >
              Confirm Appointment
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Confirmation Dialog */}
      <Dialog open={showConfirmation} onOpenChange={setShowConfirmation}>
        <DialogContent className="max-w-md">
          <div className="text-center py-6">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", duration: 0.6 }}
              className="inline-flex items-center justify-center w-20 h-20 bg-[#198754]/10 rounded-full mb-4"
            >
              <CheckCircle2 className="size-12 text-[#198754]" />
            </motion.div>
            <h3 className="text-2xl font-semibold mb-2">
              Appointment Confirmed!
            </h3>
            <p className="text-muted-foreground mb-6">
              You will receive a confirmation email shortly.
            </p>
            <Button onClick={() => setShowConfirmation(false)}>
              Done
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
